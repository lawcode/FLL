//
//  NetWorkingTool.swift
//  LingQi
//
//  Created by MAC on 17/3/11.
//  Copyright © 2017年 molangwu.com. All rights reserved.
//

import Foundation
import AFNetworking

public enum HTTPRequestMethod: String {
    case GET
    case POST
    
}

public protocol NetWorkingToolDelegate {
    
    func httpRequestSuccess(urlString: String, result: Any)
    
    func httpRequestFailure(urlString: String, error: Error)
    
}

protocol NetWorkingToolProtocol {
    
    static func setBaseURL(baseURL: String)
    
    static func netWorking(method: HTTPRequestMethod, urlString: String, parameters: AnyObject?, delegate: NetWorkingToolDelegate)
}

struct NetWorkingTool: NetWorkingToolProtocol {
    
    static var baseURL = ""
    static func setBaseURL(baseURL: String) {
        self.baseURL = baseURL
    }
    
    static func netWorking(method: HTTPRequestMethod, urlString: String, parameters: AnyObject?, delegate: NetWorkingToolDelegate) {
        
        let url = self.baseURL + urlString
        let AFN = AFHTTPSessionManager()
        
        //AFN 默认只支持以下几种数据格式的解析 @"application/json", @"text/json", @"text/javascript"
        AFN.responseSerializer.acceptableContentTypes?.insert("text/plain")
        AFN.responseSerializer.acceptableContentTypes?.insert("text/html")

        
        let homePath = NSHomeDirectory() + "/Documents"
        let timeFormatter = DateFormatter()
        timeFormatter.dateFormat = "yyy-MM-dd-HH-mm-ss"
        var urlType = ""
        switch urlString {
            case URLEnum.checkLogin.rawValue: urlType = "CheckLogin-"
            case URLEnum.getTask.rawValue: urlType = "GetTask-"
            case URLEnum.submitFormData.rawValue: urlType = "SubmitFormData-"
            case URLEnum.uploadImage.rawValue: urlType = "UploadImage-"
            default: urlType = "Unknown-"
        }
        
        let currentTime =  timeFormatter.string(from: Date())
        let requstFilePath = homePath + "/FLL/Request/" + urlType + currentTime + ".txt"
        let reponseSuccessFilePath = homePath + "/FLL/Response/" + "Success: " + urlType + currentTime + ".txt"
        let reponseFailureFilePath = homePath + "/FLL/Response/" + "Failure: " + urlType + currentTime + ".txt"
        
        FLLFileManager.createFolder(name: "FLL", baseUrl: NSURL(fileURLWithPath: homePath))
        FLLFileManager.createFolder(name: "Request", baseUrl: NSURL(fileURLWithPath: homePath + "/FLL"))
        FLLFileManager.createFolder(name: "Response", baseUrl: NSURL(fileURLWithPath: homePath + "/FLL"))
        
        if let dataString = parameters?.description {
            FLLFileManager.writeString(toFilePath: requstFilePath, dataString: dataString)
        }
        
        switch method {
        case HTTPRequestMethod.GET:
            //GET请求
            AFN.get(url, parameters: parameters, progress: nil, success: { (_, result) in
                if let resultData  = result{
                    
                    if let dataString = parameters?.description {
                        FLLFileManager.writeString(toFilePath: reponseSuccessFilePath, dataString: dataString)
                    }
                    
                    delegate.httpRequestSuccess(urlString: urlString, result: resultData)
                }
                }, failure: { (_, error) in
                    
                    FLLFileManager.writeString(toFilePath: reponseFailureFilePath, dataString: error.localizedDescription)
                    
                    delegate.httpRequestFailure(urlString: urlString, error: error)
            })
            
        case HTTPRequestMethod.POST:
            //POST请求
            AFN.post(url, parameters: parameters, progress: nil, success: { (_, result) in
                
                if let resultData = result {
                    
                    if let dataString = parameters?.description {
                        FLLFileManager.writeString(toFilePath: reponseSuccessFilePath, dataString: dataString)
                    }
                    
                    delegate.httpRequestSuccess(urlString: urlString, result: resultData)
                }
                }, failure: { (_, error) in
                    
                    FLLFileManager.writeString(toFilePath: reponseFailureFilePath, dataString: error.localizedDescription)
                    
                    delegate.httpRequestFailure(urlString: urlString, error: error)
            })
        }
        
    }
   
}
