//
//  NetWorkingObjectResult.swift
//  LingQi
//
//  Created by MAC on 17/3/11.
//  Copyright © 2017年 molangwu.com. All rights reserved.
//

import Foundation

class NetWorkingObjectResult: NSObject {
    
    var data: AnyObject?
    var msg: String = "" //success error
    
    override init() {
        super.init()
    }
    
    init(dict: [String : AnyObject]) {
        super.init()
        setValuesForKeys(dict)
    }
}
