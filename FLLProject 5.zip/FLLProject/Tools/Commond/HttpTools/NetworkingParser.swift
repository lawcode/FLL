//
//  NetworkingParserProtocol.swift
//  LingQi
//
//  Created by MAC on 17/3/11.
//  Copyright © 2017年 molangwu.com. All rights reserved.
//

import Foundation
import MJExtension

protocol NetWorkingParserProtocol {

    //解析数据
    func parserData(resultData: Any) -> NetWorkingObjectResult
    //错误码处理
    func errorCodeManage(error: Error) -> String
    
}

protocol NetWorkingParserDelegate {
    
    func parserSuccess(urlString: String, result: NetWorkingObjectResult)
    
    func parserFailure(urlString: String, error: String)
    
}

struct NetWorkingParser: NetWorkingParserProtocol, NetWorkingToolDelegate {
    
    var delegate: NetWorkingParserDelegate
    
    func parserData(resultData: Any) -> NetWorkingObjectResult {
        return NetWorkingObjectResult.mj_object(withKeyValues: resultData)
    }
   
    func errorCodeManage(error: Error) -> String {
        var errorCode: String = error.localizedDescription
        if errorCode.characters.count > 100 {

            let index = errorCode.index(errorCode.startIndex, offsetBy: 100)
            errorCode = errorCode.substring(to: index)
        }
        
        return errorCode
    }
    
    func httpRequestSuccess(urlString: String, result: Any) {
        let resultData = parserData(resultData: result)
        guard resultData.msg == "success" else {
            delegate.parserFailure(urlString: urlString, error: resultData.msg)
            return
        }
        
        delegate.parserSuccess(urlString: urlString, result: resultData)
    }
    
    func httpRequestFailure(urlString: String, error: Error) {
        
        delegate.parserFailure(urlString: urlString, error: "网络连接失败！")
    }
    
}

