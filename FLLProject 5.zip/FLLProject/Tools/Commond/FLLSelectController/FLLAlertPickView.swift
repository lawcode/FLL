//
//  FLLAlertPickView.swift
//  FLLProject
//
//  Created by molangwu on 2017/4/26.
//  Copyright © 2017年 law.com. All rights reserved.
//

import UIKit

protocol FLLAlertPickViewDelegate: NSObjectProtocol {
    
    func selectRow(type: String, row: Int)
}

class FLLAlertPickView: UIView, UITableViewDataSource, UITableViewDelegate {

    private var type = "minute"
    private var data: [Int] = []
    var cellHeight = CGFloat(50)
    var tableView: UITableView!
    weak var delegate: FLLAlertPickViewDelegate?
    
    init(frame: CGRect, type: String, data: [Int]) {
        super.init(frame: frame)
        initView()
        self.type = type
        self.data = data
        self.tableView.reloadData()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func initView() {
        
        tableView = UITableView(frame: self.frame)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
        tableView.register(UITableViewCell.classForCoder(), forCellReuseIdentifier: "cell")
        self.addSubview(tableView)
    }

    // MARK: - Table view data source
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = "\(data[indexPath.row])"
        cell.textLabel?.font = UIFont.boldSystemFont(ofSize: 22)
        cell.textLabel?.textColor = UIColor.black
        cell.textLabel?.textAlignment = .center
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if let delegate = delegate {
            delegate.selectRow(type: self.type, row: data[indexPath.row])
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return cellHeight
    }
}
