//
//  AnalyzeJSONTools.swift
//  FLLProject
//
//  Created by MAC on 17/3/1.
//  Copyright © 2017年 law.com. All rights reserved.
//

import Foundation
import MJExtension

class JSONAnalyzeTools: NSObject {
    
    /**
     通过本地的json文件获取数据
     
     - returns: ［FLLFormObjectResult］表单的数据
     */
    static func getFLLFormData() -> [FLLFormObjectResult] {
        
        let data: [FLLFormObjectResult] = []
        //从一个本地项目资源中读取XXX.Json文件
        guard let path: String = Bundle.main.path(forResource: "FLLFormData", ofType: "json") else {
            print("Json文件没找到")
            return data
        }
        let nsUrl = URL(fileURLWithPath: path)
        let nsData: Data = try! Data(contentsOf: nsUrl)
        do {
            //读取Json数据
            let json = try JSONSerialization.jsonObject(with: nsData, options: JSONSerialization.ReadingOptions.allowFragments)
            let resut: [FLLFormObjectResult] = FLLFormObjectResult.mj_objectArray(withKeyValuesArray: json).copy() as! [FLLFormObjectResult]
            for item in resut {
                JSONAnalyzeTools.DFS(item)
            }
            return resut
        }catch{
            print("读取Json数据失败")
        }
        return data
    }
    
    static func DFS(_ root: FLLFormObjectResult) {
        
        print(root.ItemName)
        let resut: [FLLFormObjectResult] = FLLFormObjectResult.mj_objectArray(withKeyValuesArray: root.Links).copy() as! [FLLFormObjectResult]
        for child in resut {
            if root.Links.count != 0 {
                DFS(child)
            }
            
        }
        
        
    }
    
}
