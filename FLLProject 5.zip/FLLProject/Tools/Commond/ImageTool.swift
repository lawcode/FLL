//
//  ImageTool.swift
//  FLLProject
//
//  Created by molangwu on 2017/3/25.
//  Copyright © 2017年 law.com. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD

class ImageTool: NSObject {
    
    static func uploadImage(image: UIImage) {
        
        let data = UIImagePNGRepresentation(image)!
        let imageString = data.base64EncodedString()
        
        let url = URL(string: ServiceURL + URLEnum.uploadImage.rawValue)
        var request = URLRequest(url: url!)
        request.httpMethod = "POST"
        let postString = "data:image/png;base64," + imageString
        request.httpBody = postString.data(using: .utf8)
        URLSession.shared.dataTask(with: request) { (_, _, error) in
            if let error = error {
                SVProgressHUD.showError(withStatus: error.localizedDescription)
            } else {
                SVProgressHUD.showSuccess(withStatus: "图片上传成功！")
                SVProgressHUD.dismiss(withDelay: 2)
            }
        }
        let task = URLSession.shared.dataTask(with: request)
        SVProgressHUD.show(withStatus: "上传图片中...")
        task.resume()
    }
    
    static func getBase64String(byImage image: UIImage) -> String {
        let data = UIImagePNGRepresentation(image)!
        let imageString = data.base64EncodedString()
        return "data:image/png;base64," + imageString
    }
}
