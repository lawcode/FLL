//
//  FLLFileManager.swift
//  FLLProject
//
//  Created by molangwu on 2017/4/26.
//  Copyright © 2017年 law.com. All rights reserved.
//

import Foundation

class FLLFileManager: NSObject {
    
    //        let timeFormatter = DateFormatter()
    //        timeFormatter.dateFormat = "yyy-MM-dd-HH-mm-ss"
    //        var currentTime = timeFormatter.string(from: Date())
    //        let path = NSHomeDirectory() + "/Documents" + "/FLL" + currentTime + ".txt"
    //        if let dataString = parameters?.description {
    //            try! dataString.write(toFile: path, atomically: true, encoding: .utf8)
    //
    //        }
    //        print(path)
    
    
    static func createFolder(name:String,baseUrl:NSURL) {
        
        let manager = FileManager.default
        let folder = baseUrl.appendingPathComponent(name, isDirectory: true)
        let exist = manager.fileExists(atPath: folder!.path)
        if !exist {
            do {
                try manager.createDirectory(at: folder!, withIntermediateDirectories: true,
                                             attributes: nil)
                print( name + "文件夹创建成功！")
            } catch {
                print( name + "文件夹创建失败！")
            }
        }
    }
    
    static func writeString(toFilePath filePath : String, dataString: String) {

        do {
            try dataString.write(toFile: filePath, atomically: true, encoding: String.Encoding.utf8)
            print("写字符串到" + filePath + "成功！")
        } catch {
            print("写字符串到" + filePath + "失败！")
        }
    }
}
