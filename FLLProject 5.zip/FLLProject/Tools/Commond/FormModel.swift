//
//  FormModel.swift
//  FLLProject
//
//  Created by MAC on 17/3/11.
//  Copyright © 2017年 law.com. All rights reserved.
//

import Foundation
class FormModel: NSObject {
    
    var projectId = 0
    
    var groupName = ""
    
    init(projectId: Int, groupName: String) {
    
        self.projectId = projectId
        self.groupName = groupName
    }
    
    init(dict: [String : AnyObject]) {
        super.init()
        setValuesForKeys(dict)
    }
}
