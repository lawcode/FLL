//
//  FLLRadioButton.swift
//  FLLProject
//
//  Created by MAC on 17/3/3.
//  Copyright © 2017年 law.com. All rights reserved.
//

import UIKit

class FLLRadioButton: UIButton {

    var index = 0
    
    var score = "0"
    
    var isAppend = false
    
    var number = "1"
    var currntNumber = 1
    var isChangeNumbe = false
    var isCancel = false
    init(frame: CGRect, title: String) {
        super.init(frame: frame)
        self.setTitleColor(UIColor.darkGray, for: .normal)
        self.setTitle(title, for: .normal)
        self.setImage(UIImage(named: "unchecked.png"), for: .normal)
        self.setImage(UIImage(named: "checked.png"), for: .selected)
        self.contentHorizontalAlignment = .left
        self.titleEdgeInsets = UIEdgeInsets(top: 0, left: 6, bottom: 0, right: 0)//标题右移
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
