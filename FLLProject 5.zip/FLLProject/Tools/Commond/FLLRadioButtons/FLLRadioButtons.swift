//
//  FLLRadioButton.swift
//  FLLProject
//
//  Created by MAC on 17/3/1.
//  Copyright © 2017年 law.com. All rights reserved.
//

import UIKit

//通过该代理来触发点击单选框时触发自定义的事件
protocol FLLRadioButtonsDelegate {
    func selectedRadioButton (index: Int)
}

class FLLRadioButtons: UIView {

    //存放多个单选框按钮
    private var radioButtons: [UIButton] = []
    var delegate: FLLRadioButtonsDelegate?
    
    init(frame: CGRect,radioButtonsTitle: [String]) {
        super.init(frame: frame)
        initRadioButtonByTitles(radioButtonsTitle: radioButtonsTitle)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //通过传入的单选框的标题来初始化多个RadioButton
    private func initRadioButtonByTitles(radioButtonsTitle: [String]) {
        
        let width = self.frame.size.width
        let buttonCount = radioButtonsTitle.count
        let btnHeight = self.frame.size.height / CGFloat(buttonCount)
        for i in 0..<buttonCount {
            
            let radioButton = UIButton(frame: CGRect(x: width*0.1, y: btnHeight * CGFloat(i), width: width*0.8, height: btnHeight))
            radioButton.setTitleColor(UIColor.darkGray, for: .normal)
            radioButton.setTitle(radioButtonsTitle[i], for: .normal)
            radioButton.setImage(UIImage(named: "unchecked.png"), for: .normal)
            radioButton.setImage(UIImage(named: "checked.png"), for: .selected)
            radioButton.contentHorizontalAlignment = .left
            radioButton.titleEdgeInsets = UIEdgeInsets(top: 0, left: 6, bottom: 0, right: 0)//标题右移
            radioButton.addTarget(self, action: #selector(self.setSelected(button:)), for: .touchUpInside)
            radioButtons.append(radioButton)
            self.addSubview(radioButton)
            
        }
    }
    func addRadioButton (radioButtonTitle: String, radioButtonHeight: CGFloat) {
        
        let width = self.frame.size.width
        let radioButton = UIButton(frame: CGRect(x: width*0.1, y: self.frame.size.height, width: width*0.8, height: radioButtonHeight))
        radioButton.setTitleColor(UIColor.darkGray, for: .normal)
        radioButton.setTitle(radioButtonTitle, for: .normal)
        radioButton.setImage(UIImage(named: "unchecked.png"), for: .normal)
        radioButton.setImage(UIImage(named: "checked.png"), for: .selected)
        radioButton.contentHorizontalAlignment = .left
        radioButton.titleEdgeInsets = UIEdgeInsets(top: 0, left: 6, bottom: 0, right: 0)//标题右移
        radioButton.addTarget(self, action: #selector(self.setSelected(button:)), for: .touchUpInside)
        radioButtons.append(radioButton)
        self.frame.size.height = self.frame.size.height + radioButtonHeight
        self.addSubview(radioButton)
    }
    //点击单选框时触发的事件
    @objc private func setSelected(button: UIButton) {
        let index: Int = radioButtons.index(of: button) ?? 0
        for btn in radioButtons {
            if !(btn == button) {
                btn.isSelected = false
            } else {
                btn.isSelected = true
            }
        }
        if let delegate = delegate {
            delegate.selectedRadioButton(index: index)
        }
    }

}
