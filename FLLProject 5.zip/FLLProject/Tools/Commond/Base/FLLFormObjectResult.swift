//
//  FLLFormObjectResult.swift
//  FLLProject
//
//  Created by MAC on 17/3/1.
//  Copyright © 2017年 law.com. All rights reserved.
//

import Foundation
import MJExtension

class FLLFormObjectResult: NSObject {
    
    var AccomplishSwitch = false    //是否达成标准开关
    var IsCancle = false    //是否取消任务
    var IsMinItem = false   //是否最小项
    var IsMutex = false     //是否互斥
    var ItemName = ""       //任务名称
    var Number = ""         //数量
    var Value = ""          //分值
    var AccomplishSwitchScore = ""  //完成标准的分值
    var Links: NSArray = []   //子项
    
    init(dict: [String : AnyObject]){
        super.init()
        setValuesForKeys(dict)
    }
    
    override init() {
        super.init()
    }
}
