//
//  URLEnum.swift
//  FLLProject
//
//  Created by MAC on 17/3/11.
//  Copyright © 2017年 law.com. All rights reserved.
//

import Foundation

enum URLEnum: String {
    
    case uploadImage = "/FLL/TestAction!getJsonPara.action"
    case checkLogin = "/FLL/mobile/LoginAction!checkLogerUserInMobile.action"
    case getTask = "/FLL/TaskAction!getJsonPara.action"
    case submitFormData = "/FLL/SubmitAction!submitFormData.action"
    
}
 
