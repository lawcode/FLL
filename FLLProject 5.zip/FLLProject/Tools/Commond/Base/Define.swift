//
//  Define.swift
//  FLLProject
//
//  Created by molangwu on 2017/4/28.
//  Copyright © 2017年 law.com. All rights reserved.
//

import UIKit

let DeviceWidth = UIScreen.main.bounds.size.width
let DeviceHeight = UIScreen.main.bounds.size.height

// MARK: - 打印日志

//打印
public func FLLPrint(items: Any..., file: String = #file, function: String = #function, line: Int = #line) {
    #if DEBUG
        let fileName: String = (file as NSString).lastPathComponent
        var message: String = "[\(fileName) : \(line) - \(function)] : "
        for item in items {
            message += "\(item) "
        }
        print(message)
    #endif
}
// MARK: - 断言
public func PTAssert(condition: Bool, _ message: String? = nil) {
    #if DEBUG
        if let _ = message {
            assert(condition, message!)
        } else {
            assert(condition)
        }
    #endif
}

