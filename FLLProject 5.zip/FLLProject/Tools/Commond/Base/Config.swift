//
//  Config.swift
//  FLLProject
//
//  Created by MAC on 17/3/3.
//  Copyright © 2017年 law.com. All rights reserved.
//

import UIKit

var ServiceURL = "http://lyx1095.w3.luyouxia.net"//"http://192.168.23.1:8080"//"http://lyx1095.w3.luyouxia.net" //"http://192.168.191.3:8080"

let GreenColor = UIColor(red: 64/255, green: 224/255, blue: 208/255, alpha: 0.2)
let BlueColor = UIColor(red: 135/255, green: 206/255, blue: 235/255, alpha: 0.2)
let PurpleColor = UIColor(red: 160/255, green: 32/255, blue: 240/255, alpha: 0.1)

