//
//  CreatFormViewByJSON.swift
//  FLLProject
//
//  Created by MAC on 17/3/2.
//  Copyright © 2017年 law.com. All rights reserved.
//

import UIKit
import MJExtension
import SVProgressHUD

//通过该代理来触发点击单选框时触发自定义的事件
protocol CreatFormViewByJSONDelegate {
    
    func selectedRadioButton(operatorString: String , radioButton: FLLRadioButton, score: Int)
    func showAlertController(radioButton: FLLRadioButton)
}

class CreatFormViewByJSON: UIScrollView {

    var itemViews: [UIView] = []
    var itemHeadLabels: [UILabel] = []
    
    var controlHeight = CGFloat(50)
    var width = CGFloat(0)
    var formHeight = CGFloat(0)   //表单高度
    var itemHeight = CGFloat(0)   //每个项目的视图的高度
    var radioButtons: [FLLRadioButton] = [] //所有的单选框
    var index = 0 //区分单选框 inde相等表示单选框互斥
    var isMutex = true // 是否是互斥项
    var isOdd = false // 是否时偶数 用于给项目的视图添加不同的背景色
    var radioButtonDelegate: CreatFormViewByJSONDelegate?
    var selectedRadioButtons: [FLLRadioButton] = [] //选中的单选框
    var labelIndexArrayDic: [UILabel : [Int]] = [:]//把每个项目的记分label和对应的单选框存起来用于计算每个项目的分数
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initView()
        //fatalError("init(coder:) has not been implemented")
        
    }
    //用于很竖屏切换时保证界面布局不会乱
    func initframe(width: CGFloat, height: CGFloat) {
        
        for itemView in itemViews {
            itemView.frame.size.width = width
        }
        for itemHeadLabel in itemHeadLabels {
            itemHeadLabel.frame = CGRect(x: 0.75 * width, y: 0, width: 0.2 * width, height: controlHeight)
        }
    }

    func selectDefalutRadioButton() {
        for button in radioButtons {
            if button.currentTitle == "未完成" {
                setSelected(button: button)
            }
        }
    }
    //初始化视图
    func initView() {
        
        width = frame.size.width
        self.autoresizingMask = .flexibleHeight
        self.scrollsToTop = false
        self.isScrollEnabled = true
        self.showsVerticalScrollIndicator = true
        self.showsHorizontalScrollIndicator = false
        analyzeJSON()
    }
    
    func loadData(paramter: FormModel) {
        
        SVProgressHUD.show(withStatus: "获取任务列表...")
        let paramter = paramter.mj_keyValues()
        NetWorkingTool.netWorking(method: .GET, urlString: URLEnum.getTask.rawValue, parameters: paramter, delegate: NetWorkingParser(delegate: self))
    }
    
    /**
     通过本地的json文件获取数据
     
     - returns: ［FLLFormObjectResult］表单的数据
     */
    private func analyzeJSON() {
        
        //从一个本地项目资源中读取XXX.Json文件
        guard let path: String = Bundle.main.path(forResource: "FLLFormData", ofType: "json") else {
            print("Json文件没找到")
            return
        }
        let nsUrl = URL(fileURLWithPath: path)
        let nsData: Data = try! Data(contentsOf: nsUrl)
        do {
            //读取Json数据
            let json = try JSONSerialization.jsonObject(with: nsData, options: JSONSerialization.ReadingOptions.allowFragments)
            let resut: [FLLFormObjectResult] = FLLFormObjectResult.mj_objectArray(withKeyValuesArray: json).copy() as! [FLLFormObjectResult]
            
            //let formView = UIView(frame: CGRect(x: 0, y: formHeight + 2, width: width, height: controlHeight))

            for item in resut {
                
                let beforeIndex = index + 1
    
                let itemView = UIView(frame: CGRect(x: 0, y: formHeight + 2, width: width, height: controlHeight))
                DFS(root: item, formView: itemView)
                itemView.frame.size.height = itemHeight
                itemHeight = CGFloat(0)
                if isOdd {
                    itemView.backgroundColor = PurpleColor
                } else {
                    itemView.backgroundColor = GreenColor
                }
                isOdd = !isOdd
        
                let itemHeadLabel = UILabel(frame: CGRect(x: 0.8 * width, y: 0, width: 0.2 * width, height: controlHeight))
                itemHeadLabel.text = "获得：" + "0" + "分" 
                var indexArray: [Int] = []
                for index in beforeIndex...index {
                    indexArray.append(index)
                }
                print(indexArray)
                labelIndexArrayDic[itemHeadLabel] = indexArray
                itemView.addSubview(itemHeadLabel)
                itemViews.append(itemView)
                itemHeadLabels.append(itemHeadLabel)
                self.addSubview(itemView)

            }
            
             //self.addSubview(formView)
            self.contentSize = CGSize(width: 0, height: formHeight )
        }catch{
            print("读取Json数据失败")
        }
    }
    
    //通过深度遍历 进行对json树的解析
    func DFS(root: FLLFormObjectResult, formView: UIView) {

        let width = self.frame.size.width

        //json解析出的界面有三种样式 通过 IsMinItem IsMutex 来区分
        if root.IsMinItem {
            if root.IsMutex {
                
                if isMutex {
                    
                    index = index + 1
                    
                    let radioButton = FLLRadioButton(frame: CGRect(x: width*0.1, y: itemHeight, width: width*0.8, height: controlHeight), title: "未完成")
                    radioButton.index = index
                    radioButton.number = root.Number
                    radioButton.isCancel = root.IsCancle
                    radioButton.addTarget(self, action: #selector(self.setSelected(button:)), for: .touchUpInside)
                    
                    radioButtons.append(radioButton)
                    itemHeight = itemHeight + controlHeight
                    formHeight = formHeight + controlHeight
                    formView.frame.size.height = formHeight
                    formView.addSubview(radioButton)
                    
                }
                
                isMutex = false
            
                let radioButton = FLLRadioButton(frame: CGRect(x: width*0.1, y: itemHeight, width: width*0.8, height: controlHeight), title: root.ItemName)
                radioButton.index = index
                radioButton.number = root.Number
                radioButton.isCancel = root.IsCancle
                radioButton.addTarget(self, action: #selector(self.setSelected(button:)), for: .touchUpInside)
                radioButtons.append(radioButton)
                if root.IsCancle {
                    radioButton.score = "\(-2 * Int(root.Value)!)"
                } else {
                    radioButton.score = root.Value
                }
                itemHeight = itemHeight + controlHeight
                formHeight = formHeight + controlHeight
                formView.frame.size.height = formHeight
                formView.addSubview(radioButton)
                
            }
        }
        
        if !root.IsMinItem || !root.IsMutex {
            isMutex = true
        }
        if !root.IsMinItem {
            if !root.IsMutex {
                let titleLabel = UILabel(frame: CGRect(x: 0.1 * width, y: itemHeight, width: 0.8 * width, height: controlHeight))
                titleLabel.text = root.ItemName
                itemHeight = itemHeight + controlHeight
                formHeight = formHeight + controlHeight
                formView.frame.size.height = formHeight
                formView.addSubview(titleLabel)

            }
        }
        
        if root.IsMinItem {
            if !root.IsMutex {
                
                index = index + 1
                
                let titleLabel = UILabel(frame: CGRect(x: 0.1 * width, y: itemHeight, width: 0.8 * width, height: controlHeight))
                titleLabel.text = root.ItemName
                itemHeight = itemHeight + controlHeight
                formHeight = formHeight + controlHeight
                formView.frame.size.height = formHeight
                formView.addSubview(titleLabel)
                
                let radioButton = FLLRadioButton(frame: CGRect(x: width*0.1, y: itemHeight, width: width*0.8, height: controlHeight), title: "未完成")
                radioButton.index = index
                radioButton.isCancel = root.IsCancle
                radioButton.addTarget(self, action: #selector(self.setSelected(button:)), for: .touchUpInside)
                radioButtons.append(radioButton)
                itemHeight = itemHeight + controlHeight
                formHeight = formHeight + controlHeight
                formView.frame.size.height = formHeight
                formView.addSubview(radioButton)
                
                let radioButton1 = FLLRadioButton(frame: CGRect(x: width*0.1, y: itemHeight, width: width*0.8, height: controlHeight), title: "完成")
                radioButton1.addTarget(self, action: #selector(self.setSelected(button:)), for: .touchUpInside)
                radioButton1.index = index
                radioButton1.isCancel = root.IsCancle
                radioButton1.number = root.Number
                radioButtons.append(radioButton1)
                if root.IsCancle {
                    radioButton1.score = "\(-2 * Int(root.Value)!)"
                } else {
                    radioButton1.score = root.Value
                }
                itemHeight = itemHeight + controlHeight
                formHeight = formHeight + controlHeight
                formView.frame.size.height = formHeight
                formView.addSubview(radioButton1)
                
                
            }
        }
        
        let nodeArray: [FLLFormObjectResult] = FLLFormObjectResult.mj_objectArray(withKeyValuesArray: root.Links).copy() as! [FLLFormObjectResult]
        
        for child in nodeArray {
            
            if root.Links.count != 0 {
                
                DFS(root: child, formView: formView)
                
            }
            
        }
        
        
    }
    
    //点击单选框时触发的事件
    func setSelected(button: FLLRadioButton) {
        
        for btn in radioButtons {
            if (btn.index == button.index) {
                
                btn.isSelected = false
            }
        }
        
        button.isSelected = true
        
        if !selectedRadioButtons.contains(button) {
            selectedRadioButtons.append(button)
        }
        
        if let delegate = radioButtonDelegate,Int(button.number)! > 1 {
            delegate.showAlertController(radioButton: button)
            
        } else {
            
            countScore(button: button)
        }
    }
    
    //改变数量时的计算方法
    func changeCount(beforenNumber: Int, button: FLLRadioButton) {
        
        let beforeScoreString = "\(Int(button.score)! * beforenNumber)"
        let appendString =  "            获得：" + beforeScoreString + "分"
        let title = (button.currentTitle!).replacingOccurrences(of: appendString, with: "")
        button.setTitle(title, for: .normal)
        button.isAppend = false
        if let delegate = radioButtonDelegate {
            delegate.selectedRadioButton(operatorString: "-", radioButton: button, score: Int(button.score)! * beforenNumber)
            countItemHeadLabelScore(index: button.index, score: Int(button.score)! * beforenNumber, operation: "-")
        }
        let scoreString = "\(Int(button.score)! * button.currntNumber)"
        let appendString1 =  "            获得：" + scoreString + "分"
        let title1 = (button.currentTitle!).appending(appendString1)
        button.setTitle(title1, for: .normal)
        button.isAppend = true
        if let delegate = radioButtonDelegate {
            
            let count = Int(button.number)!
            let radioButtonScore = count > 1 ?  Int(button.score)! * button.currntNumber : Int(button.score)!
            delegate.selectedRadioButton(operatorString: "+", radioButton: button,score: radioButtonScore)
            countItemHeadLabelScore(index: button.index, score: radioButtonScore, operation: "+")
            
        }
        
    }
    
    //计算获取的分数
    func countScore(button: FLLRadioButton) {
        
        if !button.isAppend {
            
            let scoreString = "\(Int(button.score)! * button.currntNumber)"
            let appendString =  "            获得：" + scoreString + "分"
            let title = (button.currentTitle!).appending(appendString)
            button.setTitle(title, for: .normal)
            button.isAppend = true
            if let delegate = radioButtonDelegate {
                let count = Int(button.number)!
                let radioButtonScore = count > 1 ?  Int(button.score)! * button.currntNumber : Int(button.score)!
                delegate.selectedRadioButton(operatorString: "+", radioButton: button, score: radioButtonScore)
                countItemHeadLabelScore(index: button.index, score: radioButtonScore, operation: "+")
            }
        }
        
        for i in 0..<selectedRadioButtons.count {
            if selectedRadioButtons[i].isAppend ,!selectedRadioButtons[i].isSelected {
                
                let scoreString = "\(Int(selectedRadioButtons[i].score)! * selectedRadioButtons[i].currntNumber)"
                let appendString =  "            获得：" + scoreString + "分"
                let title = (selectedRadioButtons[i].currentTitle!).replacingOccurrences(of: appendString, with: "")
                selectedRadioButtons[i].setTitle(title, for: .normal)
                selectedRadioButtons[i].isAppend = false
                selectedRadioButtons[i].isChangeNumbe = false
                if let delegate = radioButtonDelegate {
                    let count = Int(selectedRadioButtons[i].number)!
                    let radioButtonScore = count > 1 ?  Int(selectedRadioButtons[i].score)! * selectedRadioButtons[i].currntNumber : Int(selectedRadioButtons[i].score)!
                    delegate.selectedRadioButton(operatorString: "-", radioButton: selectedRadioButtons[i], score: radioButtonScore)
                    countItemHeadLabelScore(index: selectedRadioButtons[i].index, score: radioButtonScore, operation: "-")
                }
                selectedRadioButtons.remove(at: i)
                break
            }
        }

        
    }

    //重置数据
    func resetForm() {
        
        for radionButton in selectedRadioButtons {
            let count = Int(radionButton.number)!
            let radioButtonScore = count > 1 ?  Int(radionButton.score)! * radionButton.currntNumber : Int(radionButton.score)!
            let appendString =  "            获得：" + "\(radioButtonScore)" + "分"
            let title = (radionButton.currentTitle!).replacingOccurrences(of: appendString, with: "")
            radionButton.setTitle(title, for: .normal)
            radionButton.isSelected = false
            radionButton.isAppend = false
            radionButton.currntNumber = 1
            radionButton.isChangeNumbe = false
            
        }
        
        selectedRadioButtons.removeAll()
        
        for (label,_) in labelIndexArrayDic {
            label.text = "获得：" + "0" + "分"
        }
        self.selectDefalutRadioButton()
    }
    
    // 计算 每个项目的得分数
    func countItemHeadLabelScore(index: Int , score: Int, operation: String) {
        for (label,indexArray) in labelIndexArrayDic {
            for index1 in indexArray {
                if index1 == index {
                    let labelScoreString = (label.text!).replacingOccurrences(of: "获得：", with: "").replacingOccurrences(of: "分", with: "")
                    if operation == "+" {
                        label.text = "获得：" + "\(Int(labelScoreString)! + score)" + "分"
                    } else {
                        label.text =  "获得：" + "\(Int(labelScoreString)! - score)" + "分"
                    }
                }
            }
        }
    }
    
}
