//
//  SignatureViewController.swift
//  FLLProject
//
//  Created by MAC on 17/3/6.
//  Copyright © 2017年 law.com. All rights reserved.
//

import UIKit

class SignatureViewController: UIViewController {
    
    
    var racerOneNameLabel: UILabel?
    var racerTwoNameLabel: UILabel?
    var judgeNameLabel: UILabel?
    var headJudgeNameLabel: UILabel?
    
    var racerImageView: UIImageView?
    var judgeImageView: UIImageView?
    var signatureView: DrawSignatureView?
    
    var clearSignatureButton: UIButton?
    var saveSignatureForRacerButton: UIButton?
    var saveSignatureForJudgeButton: UIButton?

    let headLabelText = ["参赛员: ","参赛员: ","裁判: ","裁判长: "]
    var itemModel = FLLLoginItemListModel()
    var racerOneName = ""
    var racerTwoName = ""
    var judgeName = ""
    var headJudgeName = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func initFrame(width: CGFloat, height: CGFloat) {
        
        racerOneNameLabel?.frame = CGRect(x: 0.05 * width, y: 0, width: 0.9 * width/4, height: 50)
        racerTwoNameLabel?.frame = CGRect(x: 0.05 * width + 0.9 * width/4, y: 0, width: 0.9 * width/4, height: 50)
        judgeNameLabel?.frame = CGRect(x: 0.05 * width + 0.9 * width/2, y: 0, width: 0.9*width/4, height: 50)
        headJudgeNameLabel?.frame = CGRect(x: 0.05 * width + 0.9 * width / 4 * 3, y: 0, width: 0.9 * width/4, height: 50)
        
        
        racerImageView?.frame = CGRect(x: 0.05 * width, y:  50, width: width*0.4, height: 0.5 * height  - 50)
        judgeImageView?.frame = CGRect(x: 0.55 * width, y: 50, width: width*0.4, height: 0.5 * height  - 50)
        signatureView?.frame = CGRect(x: 0.05 * width  + 2, y: 0.5 * height + 2, width: 0.9 * width , height: 0.5 * height - 54)
        
        clearSignatureButton?.frame = CGRect(x: 0.05 * width, y: height - 50, width: 0.3 * width, height: 50)
        saveSignatureForRacerButton?.frame = CGRect(x: 0.35 * width, y: height - 50, width: 0.3 * width, height: 50)
        saveSignatureForJudgeButton?.frame = CGRect(x: 0.65 * width, y: height - 50, width: 0.3 * width, height: 50)
        
    }
    

    func initView(width: CGFloat, height: CGFloat) {
        
        racerOneNameLabel = UILabel(frame: CGRect(x: 0.05 * width, y: 0, width: 0.9 * width/4, height: 50))
        racerOneNameLabel?.text = headLabelText[0] + racerOneName
        racerOneNameLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        racerOneNameLabel?.textAlignment = .left
        
        racerTwoNameLabel = UILabel(frame: CGRect(x: 0.05 * width + 0.9 * width/4, y: 0, width: 0.9 * width/4, height: 50))
        racerTwoNameLabel?.text = headLabelText[1] + racerTwoName
        racerTwoNameLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        racerTwoNameLabel?.textAlignment = .center
        
        judgeNameLabel = UILabel(frame: CGRect(x: 0.05 * width + 0.9 * width/2, y: 0, width: 0.9*width/4, height: 50))
        judgeNameLabel?.text = headLabelText[2] + judgeName
        judgeNameLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        judgeNameLabel?.textAlignment = .center
        
        headJudgeNameLabel = UILabel(frame: CGRect(x: 0.05 * width + 0.9 * width / 4 * 3, y: 0, width: 0.9 * width/4, height: 50))
        headJudgeNameLabel?.text = headLabelText[3] + headJudgeName
        headJudgeNameLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        headJudgeNameLabel?.textAlignment = .right
        
        self.view.addSubview(racerOneNameLabel!)
        self.view.addSubview(racerTwoNameLabel!)
        self.view.addSubview(judgeNameLabel!)
        self.view.addSubview(headJudgeNameLabel!)
        
        racerImageView = UIImageView(frame: CGRect(x: 0.05 * width, y:  50, width: width*0.4, height: 0.5 * height  - 50))
        racerImageView?.backgroundColor = UIColor.white
        //racerImageView?.image = UIImage(named: "image")
        judgeImageView = UIImageView(frame: CGRect(x: 0.55 * width, y: 50, width: width*0.4, height: 0.5 * height  - 50))
        judgeImageView?.backgroundColor = UIColor.white
        //judgeImageView?.image = UIImage(named: "image")

        self.view.addSubview(racerImageView!)
        self.view.addSubview(judgeImageView!)
        
        signatureView = DrawSignatureView(frame: CGRect(x: 0.05 * width + 2, y: 0.5 * height + 2, width: 0.9 * width , height: 0.5 * height - 54))
        signatureView?.layer.borderColor = UIColor.blue.cgColor
        signatureView?.layer.borderWidth = 2
        self.view.addSubview(signatureView!)
        
        clearSignatureButton = UIButton(frame: CGRect(x: 0.05 * width, y: height - 50, width: 0.3 * width , height: 50))
        clearSignatureButton?.setTitle("清空画板", for: .normal)
        clearSignatureButton?.addTarget(self, action: #selector(self.clearSignature(button:)), for: .touchUpInside)
        clearSignatureButton?.setTitleColor(UIColor.blue, for: .normal)
        clearSignatureButton?.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        clearSignatureButton?.contentHorizontalAlignment = .left
        
        saveSignatureForRacerButton = UIButton(frame: CGRect(x: 0.35 * width, y: height - 50, width: 0.3 * width, height: 50))
        saveSignatureForRacerButton?.setTitle("保持参赛者签名", for: .normal)
        saveSignatureForRacerButton?.addTarget(self, action: #selector(self.saveSignatureForRacer(button:)), for: .touchUpInside)
        saveSignatureForRacerButton?.setTitleColor(UIColor.blue, for: .normal)
        saveSignatureForRacerButton?.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        saveSignatureForRacerButton?.contentHorizontalAlignment = .center
        
        saveSignatureForJudgeButton = UIButton(frame: CGRect(x: 0.65 * width, y: height - 50, width: 0.3 * width, height: 50))
        saveSignatureForJudgeButton?.setTitle("保持裁判签名", for: .normal)
        saveSignatureForJudgeButton?.addTarget(self, action: #selector(self.saveSignatureForJudge(button:)), for: .touchUpInside)
        saveSignatureForJudgeButton?.setTitleColor(UIColor.blue, for: .normal)
        saveSignatureForJudgeButton?.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        saveSignatureForJudgeButton?.contentHorizontalAlignment = .right
        
        self.view.addSubview(clearSignatureButton!)
        self.view.addSubview(saveSignatureForRacerButton!)
        self.view.addSubview(saveSignatureForJudgeButton!)
    }

    
    func clearSignature(button: UIButton) {
        self.signatureView?.clearSignature()
        
    }
    
    func saveSignatureForRacer(button: UIButton) {
        self.racerImageView?.image = signatureView?.getSignature()
    }
    
    func saveSignatureForJudge(button: UIButton) {
        self.judgeImageView?.image = signatureView?.getSignature()
    }
    
    func resetImage() {
        racerImageView?.image = nil
        judgeImageView?.image = nil
        self.signatureView?.clearSignature()
    }

}
