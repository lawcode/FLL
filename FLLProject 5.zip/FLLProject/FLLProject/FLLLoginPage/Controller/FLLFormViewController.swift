//
//  FLLFormViewController.swift
//  FLLProject
//
//  Created by MAC on 17/3/1.
//  Copyright © 2017年 law.com. All rights reserved.
//

import UIKit
import SVProgressHUD

class FLLFormViewController: UIViewController, CreatFormViewByJSONDelegate, FLLSelectTableViewControllerDelegate, FLLAlertPickViewDelegate {
    
    var titleLabel: UILabel!
    
    var groupLabel: UILabel!
    var positionLabel: UILabel!
    var roundLabel: UILabel!
    var areaLabel: UILabel!
    var totalScoreLabel: UILabel!
    var selectMinuteLabel: UILabel!
    var selectSecondLabel: UILabel!
    
    var formScrollView: CreatFormViewByJSON!
    
    var submitButton: UIButton!
    var resetButton: UIButton!
    var signatureButton: UIButton!
    var logoutButton: UIButton!
    
    var itemListModel: [FLLLoginItemListModel] = []

    var loginRequestModel = FLLLoginRequestModel()
    var loginResponseModel = FLLLoginResponseModel()
    var selectAreaRow = 0
    var selectTimeAlertController: UIAlertController?
    lazy var signaturePopoverViewController: SignatureViewController = {
        return  SignatureViewController()
    }()
    
    var headLabelText = ["组别: ","赛台: ","参赛队: ","轮数: ","总分: "]
    var areaText = ["中国福建省厦门市集美区集美队","福州队"]
    var roundText = ["1","2","3","4","5","6"]
    var groupText = "小学组"
    var positionText = "1"
    var minute = 2
    var second = 30
    var currentSelectRound = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        
        initData()
        initView()
    }
    
    func initData() {
        areaText.removeAll()
        if itemListModel.isEmpty {
            itemListModel.append(FLLLoginItemListModel())
        } else {
            for item in itemListModel {
                areaText.append(item.schoolName + "-" + item.teamName)
            }
        }
    }
    
    func initFormViewData() {
        let paramter = FormModel(projectId: itemListModel[selectAreaRow].projectId, groupName: groupText)
        //formScrollView.loadData(paramter: paramter)
    }
    
    //旋转屏幕时 对界面重修布局
    func initframe(width: CGFloat, height: CGFloat) {
        
        titleLabel.frame = CGRect(x: 0, y: 20, width: width, height: 60)
        groupLabel.frame = CGRect(x: 0.05 * width, y: 80, width: 0.225 * width, height: 50)
        positionLabel.frame = CGRect(x: 0.275 * width, y: 80, width: 0.225 * width, height: 50)
        roundLabel.frame = CGRect(x: 0.5 * width , y: 80, width: 0.225 * width, height: 50)
        totalScoreLabel.frame = CGRect(x: 0.725 * width, y: 80, width: 0.225 * width, height: 50)
        areaLabel.frame = CGRect(x: 0.05 * width, y: 130, width: 0.9*width, height: 50)
        
        selectMinuteLabel.frame = CGRect(x: 0.3 * width, y: 180, width: 0.2 * width , height: 50)
        selectSecondLabel.frame = CGRect(x: 0.5 * width, y: 180, width: 0.2 * width , height: 50)
        
        formScrollView.frame = CGRect(x:0.05 * width, y: 240, width: 0.9 * width , height:  height - 300)
        formScrollView.layer.borderWidth = 1
        formScrollView.layer.cornerRadius = 20
        formScrollView.layer.borderColor = UIColor.blue.cgColor
        formScrollView.initframe(width: width, height: height)
        
        submitButton.frame = CGRect(x: 0.05 * width, y: height - 50, width: 0.3 * width, height: 50)
        resetButton.frame = CGRect(x: 0.35 * width, y: height - 50, width: 0.3 * width, height: 50)
        signatureButton.frame = CGRect(x: 0.65 * width, y: height - 50, width: 0.3 * width, height: 50)
        logoutButton.frame = CGRect(x: 0.95 * width - 80, y: 20, width: 80, height: 60)
        signaturePopoverViewController.preferredContentSize = CGSize(width: 0.7 * width, height: 0.7 * height)
        signaturePopoverViewController.initFrame(width: 0.7 * width, height: 0.7 * height)
        
        
    }
    
    //初始化视图
    func initView() {
        
        let height = self.view.frame.height
        let width = self.view.frame.width
        self.view.backgroundColor = UIColor.white
        titleLabel = UILabel(frame: CGRect(x: 0, y: 20, width: width, height: 60))
        titleLabel.text = "第十五届福建省青少年机器人竞赛 fll机器人挑战赛记分表"
        titleLabel.font = UIFont.boldSystemFont(ofSize: 22)
        titleLabel.textAlignment = .center
        
        logoutButton = UIButton(frame: CGRect(x: 0.95 * width - 80, y: 20, width: 80, height: 60))
        logoutButton.setTitle("注销", for: .normal)
        logoutButton.addTarget(self, action: #selector(self.logout(button:)), for: .touchUpInside)
        logoutButton.setTitleColor(UIColor.blue, for: .normal)
        logoutButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        logoutButton.contentHorizontalAlignment = .right
        
        groupLabel = UILabel(frame: CGRect(x: 0.05 * width, y: 80, width: 0.225 * width, height: 50))
        groupLabel.text = headLabelText[0] + groupText
        groupLabel.font = UIFont.boldSystemFont(ofSize: 20)
        groupLabel.textAlignment = .left
        
        roundLabel = UILabel(frame: CGRect(x: 0.275 * width , y: 80, width: 0.225 * width, height: 50))
        roundLabel.text = headLabelText[3] + roundText[0]
        roundLabel.font = UIFont.boldSystemFont(ofSize: 20)
        roundLabel.textAlignment = .center
        roundLabel.tag = 1000
        roundLabel.isUserInteractionEnabled = true
        roundLabel.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(self.showSelectController(recognizer:))))
        
        positionLabel = UILabel(frame: CGRect(x: 0.5 * width , y: 80, width: 0.225 * width, height: 50))
        positionLabel.font = UIFont.boldSystemFont(ofSize: 20)
        positionLabel.textAlignment = .center
        positionLabel.tag = 1001
        positionLabel.text = headLabelText[1] + positionText
        
        totalScoreLabel = UILabel(frame: CGRect(x: 0.725 * width, y: 80, width: 0.225 * width, height: 50))
        totalScoreLabel.text = headLabelText[4] + "0"
        totalScoreLabel.font = UIFont.boldSystemFont(ofSize: 20)
        totalScoreLabel.textAlignment = .right
        
        areaLabel = UILabel(frame: CGRect(x: 0.05 * width, y: 130, width: 0.9 * width , height: 50))
        areaLabel.text = areaText.count > 0 ? headLabelText[2] + areaText[0] : headLabelText[2]
        areaLabel.font = UIFont.boldSystemFont(ofSize: 20)
        areaLabel.textAlignment = .center
        areaLabel.tag = 1002
        areaLabel.isUserInteractionEnabled = true
        areaLabel.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(self.showSelectController(recognizer:))))
        
        selectMinuteLabel = UILabel(frame: CGRect(x: 0.3 * width, y: 180, width: 0.2 * width , height: 50))   // UIPickerView(frame: CGRect(x: 0.3 * width, y: 180, width: 0.4 * width , height: 50))
        selectMinuteLabel.text = "时间： 2分钟"
        selectMinuteLabel.font = UIFont.boldSystemFont(ofSize: 20)
        selectMinuteLabel.textAlignment = .center
        selectMinuteLabel.tag = 1003
        selectMinuteLabel.isUserInteractionEnabled = true
        selectMinuteLabel.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(self.showSelectMinuteAction(recognizer:))))
        
        selectSecondLabel = UILabel(frame: CGRect(x: 0.5 * width, y: 180, width: 0.2 * width , height: 50))   // UIPickerView(frame: CGRect(x: 0.3 * width, y: 180, width: 0.4 * width , height: 50))
        selectSecondLabel.text = " 30秒"
        selectSecondLabel.font = UIFont.boldSystemFont(ofSize: 20)
        selectSecondLabel.textAlignment = .center
        selectSecondLabel.tag = 1004
        selectSecondLabel.isUserInteractionEnabled = true
        selectSecondLabel.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(self.showSelectSecondAction(recognizer:))))
        
        //selectTimePickView.delegate = self
        //selectTimePickView.dataSource = self
        
        self.view.addSubview(logoutButton)
        self.view.addSubview(titleLabel)
        self.view.addSubview(groupLabel)
        self.view.addSubview(roundLabel)
        self.view.addSubview(positionLabel)
        self.view.addSubview(areaLabel)
        self.view.addSubview(totalScoreLabel)
        self.view.addSubview(selectMinuteLabel)
        self.view.addSubview(selectSecondLabel)
        
        formScrollView = CreatFormViewByJSON(frame: CGRect(x:0.05 * width, y: 240, width: 0.9*width , height: height - 300))
        formScrollView.layer.borderWidth = 1
        formScrollView.layer.cornerRadius = 20
        formScrollView.layer.borderColor = UIColor.blue.cgColor
        formScrollView.radioButtonDelegate = self
        self.view.addSubview(formScrollView)
        initFormViewData()
        
        submitButton = UIButton(frame: CGRect(x: 0.05 * width, y: height - 50, width: 0.3 * width, height: 50))
        submitButton.setTitle("提交", for: .normal)
        submitButton.addTarget(self, action: #selector(self.submitForm(button:)), for: .touchUpInside)
        submitButton.setTitleColor(UIColor.blue, for: .normal)
        submitButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        submitButton.contentHorizontalAlignment = .left
        
        resetButton = UIButton(frame: CGRect(x: 0.35 * width, y: height - 50, width: 0.3 * width, height: 50))
        resetButton.setTitle("重置", for: .normal)
        resetButton.addTarget(self, action: #selector(self.resetForm(button:)), for: .touchUpInside)
        resetButton.setTitleColor(UIColor.blue, for: .normal)
        resetButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        resetButton.contentHorizontalAlignment = .center
        
        signatureButton = UIButton(frame: CGRect(x: 0.65 * width, y: height - 50, width: 0.3 * width, height: 50))
        signatureButton.setTitle("签名", for: .normal)
        signatureButton.addTarget(self, action: #selector(self.signature(button:)), for: .touchUpInside)
        signatureButton.setTitleColor(UIColor.blue, for: .normal)
        signatureButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 20)
        signatureButton.contentHorizontalAlignment = .right

        self.view.addSubview(submitButton)
        self.view.addSubview(resetButton)
        self.view.addSubview(signatureButton)
        
        signaturePopoverViewController.initView(width: 0.7 * width, height: 0.7 * height)
        signaturePopoverViewController.preferredContentSize = CGSize(width: 0.7 * width, height: 0.7 * height)
        
    }
    
    override func viewWillLayoutSubviews() {
        
        initframe(width: self.view.frame.size.width, height: self.view.frame.size.height)
    }
    
    //提交
    func submitForm(button: UIButton) {
        
//        let round = (roundLabel.text!).replacingOccurrences(of: headLabelText[3], with: "")
//        var dic: [String: AnyObject] = [:]
//        dic["timeMin"] = minute as AnyObject?
//        dic["timeSec"] = second as AnyObject?
//        dic["projectId"] = itemListModel[selectAreaRow].projectId as AnyObject?
//        dic["partId"] = itemListModel[selectAreaRow].partId as AnyObject?
//        dic["judgerId"] = loginResponseModel.judgerId as AnyObject?
//        dic["mainJudgerId"] = loginResponseModel.mainJudgerId as AnyObject?
//        dic["rould"] =  Int(round) as AnyObject? // Int(roundLabel.text!) as AnyObject?
//        for i in 0..<formScrollView.selectedRadioButtons.count {
//            
//            dic["taskIdList[" + "\(i)" + "]"] = i as AnyObject?
//            //dic["scoreList[" + "\(i)" + "]"] = 0 as AnyObject?
//            
//            for j in 0..<formScrollView.selectedRadioButtons.count {
//                if formScrollView.selectedRadioButtons[j].index - 1 == i {
//                    dic["scoreList[" + "\(i)" + "]"] = Int(formScrollView.selectedRadioButtons[j].score)! * formScrollView.selectedRadioButtons[j].currntNumber as AnyObject?
//                }
//            }
//            
//            
//        }
//        print(dic)
//        if let raceImage = signaturePopoverViewController.racerImageView?.image, let judgerImage = signaturePopoverViewController.judgeImageView?.image {
//            dic["sign_participant"] = ImageTool.getBase64String(byImage: raceImage) as AnyObject?
//            dic["sign_judger"] = ImageTool.getBase64String(byImage: judgerImage) as AnyObject?
//            SVProgressHUD.show(withStatus: "提交中...")
//            NetWorkingTool.netWorking(method: .POST, urlString: URLEnum.submitFormData.rawValue, parameters: dic as AnyObject?, delegate: NetWorkingParser(delegate: self))
//        } else {
//            let alert = UIAlertController(title: "提示", message: "请先签名", preferredStyle: .alert)
//            alert.addAction(UIAlertAction(title: "确定", style: .default, handler: nil))
//            self.show(alert, sender: nil)
//        }
        
        let alertController = UIAlertController(title: "请确认所要的提交信息", message: "是否提交", preferredStyle: .alert)
        let yesAction = UIAlertAction(title: "确认", style: .default) {
            [weak self] (action) in
            if let weakSelf = self {
                let round = (weakSelf.roundLabel.text!).replacingOccurrences(of: weakSelf.headLabelText[3], with: "")
                var dic: [String: AnyObject] = [:]
                dic["timeMin"] = weakSelf.minute as AnyObject?
                dic["timeSec"] = weakSelf.second as AnyObject?
                dic["projectId"] = weakSelf.itemListModel[weakSelf.selectAreaRow].projectId as AnyObject?
                dic["partId"] = weakSelf.itemListModel[weakSelf.selectAreaRow].partId as AnyObject?
                dic["judgerId"] = weakSelf.loginResponseModel.judgerId as AnyObject?
                dic["mainJudgerId"] = weakSelf.loginResponseModel.mainJudgerId as AnyObject?
                dic["rould"] =  Int(round) as AnyObject? // Int(roundLabel.text!) as AnyObject?
                for i in 0..<weakSelf.formScrollView.selectedRadioButtons.count {
                    
                    dic["taskIdList[" + "\(i)" + "]"] = i as AnyObject?
                    
                    for j in 0..<weakSelf.formScrollView.selectedRadioButtons.count {
                        if weakSelf.formScrollView.selectedRadioButtons[j].index - 1 == i {
                            dic["scoreList[" + "\(i)" + "]"] = Int(weakSelf.formScrollView.selectedRadioButtons[j].score)! * weakSelf.formScrollView.selectedRadioButtons[j].currntNumber as AnyObject?
                        }
                    }
                    
                    
                }
                if let raceImage = weakSelf.signaturePopoverViewController.racerImageView?.image, let judgerImage = weakSelf.signaturePopoverViewController.judgeImageView?.image {
                    dic["sign_participant"] = ImageTool.getBase64String(byImage: raceImage) as AnyObject?
                    dic["sign_judger"] = ImageTool.getBase64String(byImage: judgerImage) as AnyObject?
                    SVProgressHUD.show(withStatus: "提交中...")
                    NetWorkingTool.netWorking(method: .POST, urlString: URLEnum.submitFormData.rawValue, parameters: dic as AnyObject?, delegate: NetWorkingParser(delegate: weakSelf))
                } else {
                    let alert = UIAlertController(title: "提示", message: "请先签名", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "确定", style: .default, handler: nil))
                    weakSelf.show(alert, sender: nil)
                }
            }
        }
        let noAction = UIAlertAction(title: "取消", style: .cancel, handler: nil)
        alertController.addAction(yesAction)
        alertController.addAction(noAction)
        
        self.show(alertController, sender: nil)
    }
    
    //重置
    func resetForm(button: UIButton) {
        totalScoreLabel.text = headLabelText[4] + "0"
        signaturePopoverViewController.resetImage()
        formScrollView.resetForm()
        minute = 2
        selectMinuteLabel.text = "时间： " + "\(minute)" + "分钟"
        
        second = 30
        selectSecondLabel.text = " " + "\(second)" + "秒"
    }
    
    //签名
    func signature(button: UIButton) {
        
        signaturePopoverViewController.racerOneNameLabel?.text = itemListModel[selectAreaRow].menber1
        signaturePopoverViewController.racerTwoNameLabel?.text = itemListModel[selectAreaRow].menber2
        
        signaturePopoverViewController.modalPresentationStyle = UIModalPresentationStyle.popover
        let popoverController = signaturePopoverViewController.popoverPresentationController!
        popoverController.permittedArrowDirections = .down
        popoverController.sourceRect = CGRect(x: self.signatureButton.frame.width*7/8 , y: 0, width: 20, height: 0)
        popoverController.sourceView = self.signatureButton
        
        self.present(signaturePopoverViewController, animated: true, completion: nil)
    }
    
    //注销
    func logout(button: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func showSelectMinuteAction(recognizer: UIGestureRecognizer) {
        
        var data: [Int] = []
        for i in 0..<3 {
            data.append(i)
        }
        
        selectTimeAlertController = UIAlertController(title: "选择分钟", message: "\n\n\n\n\n\n\n\n", preferredStyle: .alert)
        let alertPickView = FLLAlertPickView(frame: CGRect(x: 0, y: 25, width: 270, height: 150), type: "minute", data: data)
        alertPickView.delegate = self
        selectTimeAlertController?.addAction(UIAlertAction(title: "取消", style: .cancel, handler: nil))
        selectTimeAlertController?.view.addSubview(alertPickView)
        self.show(selectTimeAlertController!, sender: nil)
        
    }
    
    func showSelectSecondAction(recognizer: UIGestureRecognizer) {
        
        var data: [Int] = []
        let second = minute == 2 ? 31 : 60
        for i in 0..<second {
            data.append(i)
        }

        selectTimeAlertController = UIAlertController(title: "选择秒", message: "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", preferredStyle: .alert)
        let alertPickView = FLLAlertPickView(frame: CGRect(x: 0, y: 25, width: 270, height: 300), type: "second", data: data)
        alertPickView.delegate = self
        selectTimeAlertController?.view.addSubview(alertPickView)
        selectTimeAlertController?.addAction(UIAlertAction(title: "取消", style: .cancel, handler: nil))
        
        self.show(selectTimeAlertController!, sender: nil)

    }
    
    func selectRow(type: String, row: Int) {
        if type == "minute" {
            minute = row
            selectMinuteLabel.text = "时间： " + "\(minute)" + "分钟"
        } else {
            
            second = row
            selectSecondLabel.text = " " + "\(second)" + "秒"
        }
        selectTimeAlertController?.dismiss(animated: true, completion: nil)
        
    }
    // 弹出选择参赛队和赛台
    func showSelectController(recognizer: UIGestureRecognizer) {
        
        let width = self.view.frame.size.width
        
        let selectController = FLLSelectTableViewController()
        selectController.modalPresentationStyle = .popover
        
        selectController.delegate = self
        let popoverController = selectController.popoverPresentationController!
        
        popoverController.permittedArrowDirections = .up
        
        var tableViewHeight = selectController.cellHeight * CGFloat(5)
        var tableViewWidth = 0.2 * width
        if recognizer.view!.tag == areaLabel.tag {
            selectController.contentText = areaText
            popoverController.sourceRect = CGRect(x: self.areaLabel.frame.width/2 , y: 50, width: 20, height: 0)
            popoverController.sourceView = self.areaLabel
            if areaText.count < 5 {
                tableViewHeight = selectController.cellHeight * CGFloat(areaText.count)
            }
            tableViewWidth = 0.6 * width
            
        } else if recognizer.view!.tag == roundLabel.tag {
            selectController.contentText = roundText
            popoverController.sourceRect = CGRect(x: self.positionLabel.frame.width/2 , y: 50, width: 20, height: 0)
            popoverController.sourceView = self.roundLabel
            if roundText.count < 5 {
                tableViewHeight = selectController.cellHeight * CGFloat(roundText.count)
            }
            tableViewWidth = 0.2 * width
        }
        
        selectController.preferredContentSize = CGSize(width: tableViewWidth, height: tableViewHeight)
        self.present(selectController, animated: true, completion: nil)
        
    }
    
    //FLLSelectTableViewControllerDelegate代理 弹出选择框
    func selectContentText(text: String) {
        if areaText.contains(text) {
//            
//            selectAreaRow = areaText.index(of: text)!
//            areaLabel.text = headLabelText[2] + text
            let alertController = UIAlertController(title: "更改参赛队伍", message: "是否修改参数队伍", preferredStyle: .alert)
            let yesAction = UIAlertAction(title: "确认", style: .default) {
                [weak self] (action) in
                if let weakSelf = self {
                    weakSelf.selectAreaRow = weakSelf.areaText.index(of: text)!
                    weakSelf.areaLabel.text = weakSelf.headLabelText[2] + text
                }
            }
            
            let noAction = UIAlertAction(title: "取消", style: .cancel, handler: nil)
            alertController.addAction(yesAction)
            alertController.addAction(noAction)
            self.show(alertController, sender: nil)
            
        } else {
            
            let paramter = loginRequestModel
            paramter.rould = Int(text)!
            SVProgressHUD.show(withStatus: "更新轮数...")
            let paramters = paramter.mj_keyValues()
            NetWorkingTool.netWorking(method: .GET, urlString: URLEnum.checkLogin.rawValue, parameters: paramters, delegate: NetWorkingParser(delegate: self))
            currentSelectRound = Int(text)!
        }
    }
    
    // CreatFormViewByJSONDelegate 代理 计算总分
    func selectedRadioButton(operatorString: String, radioButton: FLLRadioButton, score: Int) {
        
        let totalScore = (totalScoreLabel.text!).replacingOccurrences(of: headLabelText[4], with: "")
        
        if operatorString == "+" {
            totalScoreLabel.text = headLabelText[4]  + "\(Int(totalScore)! + score)"
        } else if operatorString == "-" {
            totalScoreLabel.text = headLabelText[4]  + "\(Int(totalScore)! - score)"
        } else {
            
        }
        
    }
    
    // CreatFormViewByJSONDelegate 代理 弹出属性选择控制器
    func showAlertController(radioButton: FLLRadioButton) {
        
        let count = Int(radioButton.number)!
        
        let alertController = UIAlertController(title: "数量", message: "", preferredStyle: .alert)
        if  count > 1 {
            for i in 1..<count {
                let title = i == radioButton.currntNumber ? "✅" : "\(i)"
                let action = UIAlertAction(title: title, style: .default){
                    [weak self] (action) in
                    if let weakSelf = self {
                        if !radioButton.isChangeNumbe {
                            radioButton.currntNumber = i
                            weakSelf.formScrollView.countScore(button: radioButton)
                            radioButton.isChangeNumbe = true
                        } else {
                            let beforeNumber = radioButton.currntNumber
                            radioButton.currntNumber = i
                            weakSelf.formScrollView.changeCount(beforenNumber: beforeNumber, button: radioButton)
                        }
                        
                    }
                    
                }
                alertController.addAction(action)
            }
        }
//        let cancleAction = UIAlertAction(title: "取消", style: .cancel, handler: nil)
//        alertController.addAction(cancleAction)
        self.present(alertController, animated: true, completion: nil)
    }

}
