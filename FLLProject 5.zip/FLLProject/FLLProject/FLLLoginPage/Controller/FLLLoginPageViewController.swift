//
//  FLLLoginPageViewController.swift
//  FLLProject
//
//  Created by MAC on 17/3/6.
//  Copyright © 2017年 law.com. All rights reserved.
//

import UIKit
import SVProgressHUD

class FLLLoginPageViewController: UIViewController, FLLSelectTableViewControllerDelegate {

    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var groupLabel: UILabel!
    @IBOutlet weak var positionLabel: UILabel!
    
    var headLabelText = ["组别: ","赛台: "]
    var groupText = ["小学组","初中组","高中组"]
    var positionText = ["1","2","3"]
    var loginRequestModel = FLLLoginRequestModel()
    override func viewDidLoad() {
        super.viewDidLoad()
        initView()

        // Do any additional setup after loading the view.
    }
    
    //初始化视图
    func initView() {
        
        let changeServiceBtn = UIButton(frame: CGRect(x: 0, y: DeviceHeight * 0.9, width: DeviceWidth, height: DeviceHeight * 0.1))
        changeServiceBtn.addTarget(self, action: #selector(self.changeServiceAction), for: .touchUpInside)
        self.view.addSubview(changeServiceBtn)
    
        groupLabel.text =  headLabelText[0] + groupText[0]
        groupLabel.isUserInteractionEnabled = true
        groupLabel.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(self.showSelectController(recognizer:))))
        groupLabel.tag = 1000
        
        positionLabel.text = headLabelText[1] + positionText[0]
        positionLabel.isUserInteractionEnabled = true
        positionLabel.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(self.showSelectController(recognizer:))))
        positionLabel.tag = 1001
        
        userNameTextField.layer.borderWidth = 2
        userNameTextField.layer.borderColor = UIColor.gray.cgColor
        
        passwordTextField.layer.borderWidth = 2
        passwordTextField.layer.borderColor = UIColor.gray.cgColor
    }

    //登录
    @IBAction func loginEvent(_ sender: AnyObject) {
        
//        if let userName = userNameTextField.text , let password = passwordTextField.text, let posNum = Int(positionLabel.text!.replacingOccurrences(of: "赛台: ", with: "")) {
//            let paramter = FLLLoginRequestModel(userName: userName, userPassword: password, rould: 1, groupName: groupLabel.text!.replacingOccurrences(of: "组别: ", with: ""), posNum: posNum)
//            loginRequestModel = paramter
//            SVProgressHUD.show(withStatus: "登陆中...")
//            let paramters = paramter.mj_keyValues()
//            NetWorkingTool.netWorking(method: .GET, urlString: URLEnum.checkLogin.rawValue, parameters: paramters, delegate: NetWorkingParser(delegate: self))
//        } else {
//            let alert = UIAlertController(title: "提示", message: "帐号和密码输入错误", preferredStyle: .alert)
//            alert.addAction(UIAlertAction(title: "确定", style: .default, handler: nil))
//            alert.addAction(UIAlertAction(title: "取消", style: .cancel, handler: nil))
//            self.show(alert, sender: nil)
//        }
        
//        
        let formViewController = FLLFormViewController()
        formViewController.groupText = groupLabel.text!
        self.show(formViewController, sender: nil)
        
        //self.show(FLLFormViewController(), sender: nil)
    }
    
    //弹出选择框
    func showSelectController(recognizer: UIGestureRecognizer) {
        
        let width = self.view.frame.size.width
        
        let selectController = FLLSelectTableViewController()
        selectController.modalPresentationStyle = .popover
        
        selectController.delegate = self
        let popoverController = selectController.popoverPresentationController!
        
        popoverController.permittedArrowDirections = .down
        
        var tableViewHeight = selectController.cellHeight * CGFloat(5)
        if recognizer.view!.tag == groupLabel.tag {
            selectController.contentText = groupText
            popoverController.sourceRect = CGRect(x: groupLabel.frame.width/3 , y: 0, width: 20, height: 0)
            popoverController.sourceView = groupLabel
            if groupText.count < 5 {
                tableViewHeight = selectController.cellHeight * CGFloat(groupText.count)
            }
        } else {
            selectController.contentText = positionText
            popoverController.sourceRect = CGRect(x: self.positionLabel.frame.width * 2/3 , y: 0, width: 20, height: 0)
            popoverController.sourceView = self.positionLabel
            if positionText.count < 5 {
                tableViewHeight = selectController.cellHeight * CGFloat(positionText.count)
            }
        }
        
        selectController.preferredContentSize = CGSize(width: 0.2 * width, height: tableViewHeight)
        self.present(selectController, animated: true, completion: nil)
        
    }
    
    func changeServiceAction() {
        let alert = UIAlertController(title: "修改服务器地址", message: nil, preferredStyle: .alert)
        alert.addTextField { (textField) in
            textField.placeholder = "请输入服务器地址"
        }
        let okAction = UIAlertAction(title: "确定", style: .default) { [weak alert, weak self] (action) in
            if let weakSelf = self , let weakAlert = alert {
                if let serviceURL = weakAlert.textFields?[0].text {
                    ServiceURL = serviceURL
                    NetWorkingTool.setBaseURL(baseURL: ServiceURL)
                } else {
                    let alert = UIAlertController(title: "服务器地址不能为空", message: nil, preferredStyle: .alert)
                    let ok = UIAlertAction(title: "确定", style: .default, handler: nil)
                    alert.addAction(ok)
                    weakSelf.show(alert, sender: ok)
                }

            }
        }
        let cancelAction = UIAlertAction(title: "取消", style: .cancel, handler: nil)
        alert.addAction(okAction)
        alert.addAction(cancelAction)
        self.show(alert, sender: nil)
    }
    
    //FLLSelectTableViewControllerDelegate代理 弹出选择框
    func selectContentText(text: String) {
        if groupText.contains(text) {
            groupLabel.text = headLabelText[0] + text
        } else {
            positionLabel.text = headLabelText[1] + text
        }
    }

}
