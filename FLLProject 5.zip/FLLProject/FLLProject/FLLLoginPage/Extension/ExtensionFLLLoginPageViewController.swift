//
//  ExtensionFLLLoginPageViewController.swift
//  FLLProject
//
//  Created by molangwu on 2017/3/28.
//  Copyright © 2017年 law.com. All rights reserved.
//

import SVProgressHUD

extension FLLLoginPageViewController: NetWorkingParserDelegate {
    
    func parserSuccess(urlString: String, result: NetWorkingObjectResult) {
        
        if let resultData = result.data {
            let loginResponseModel = FLLLoginResponseModel.mj_object(withKeyValues: resultData)
            
            if let itemList: [FLLLoginItemListModel] = FLLLoginItemListModel.mj_objectArray(withKeyValuesArray: loginResponseModel?.list).copy() as? [FLLLoginItemListModel] {
                SVProgressHUD.showSuccess(withStatus: "登陆成功！")
                SVProgressHUD.dismiss(withDelay: 0.5)
                let formViewController = FLLFormViewController()
                formViewController.groupText = (self.groupLabel.text!).replacingOccurrences(of: headLabelText[0], with: "")
                formViewController.positionText = (self.positionLabel.text!).replacingOccurrences(of: headLabelText[1], with: "")
                formViewController.loginRequestModel = loginRequestModel
                formViewController.loginResponseModel = loginResponseModel!
                formViewController.itemListModel = itemList
                formViewController.signaturePopoverViewController.headJudgeName = loginResponseModel!.mainJudgerName
                formViewController.signaturePopoverViewController.judgeName = loginResponseModel!.judgerName
                self.show(formViewController, sender: nil)
//                formViewController.groupLabel.text = self.groupLabel.text
//                formViewController.positionLabel.text = self.positionLabel.text
                
                
            } else {
                SVProgressHUD.show(withStatus: "服务器出问题！")
                SVProgressHUD.dismiss(withDelay: 0.5)
            }
            
        } else {
            SVProgressHUD.show(withStatus: "服务器出问题！")
            SVProgressHUD.dismiss(withDelay: 0.5)
        }
        
    }
    
    func parserFailure(urlString: String, error: String) {
        SVProgressHUD.showError(withStatus: error)
    }
    
}
