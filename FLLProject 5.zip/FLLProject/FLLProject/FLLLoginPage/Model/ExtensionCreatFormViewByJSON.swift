//
//  ExtensionCreatFormViewByJSON.swift
//  FLLProject
//
//  Created by molangwu on 2017/3/28.
//  Copyright © 2017年 law.com. All rights reserved.
//

import UIKit
import SVProgressHUD

extension CreatFormViewByJSON: NetWorkingParserDelegate {
    
    func parserSuccess(urlString: String, result: NetWorkingObjectResult) {
        
        if let resultData = result.data, let resut: [FLLFormObjectResult] = FLLFormObjectResult.mj_objectArray(withKeyValuesArray: resultData).copy() as? [FLLFormObjectResult] {
        
            SVProgressHUD.showSuccess(withStatus: "获取成功！")
            for item in resut {
                
                let beforeIndex = index + 1
                
                let itemView = UIView(frame: CGRect(x: 0, y: formHeight + 2, width: width, height: controlHeight))
                DFS(root: item, formView: itemView)
                itemView.frame.size.height = itemHeight
                itemHeight = CGFloat(0)
                if isOdd {
                    itemView.backgroundColor = PurpleColor
                } else {
                    itemView.backgroundColor = GreenColor
                }
                isOdd = !isOdd
                
                let itemHeadLabel = UILabel(frame: CGRect(x: 0.8 * width, y: 0, width: 0.2 * width, height: controlHeight))
                itemHeadLabel.text = "获得：" + "0" + "分"
                var indexArray: [Int] = []
                for index in beforeIndex...index {
                    indexArray.append(index)
                }
                print(indexArray)
                labelIndexArrayDic[itemHeadLabel] = indexArray
                itemView.addSubview(itemHeadLabel)
                itemViews.append(itemView)
                itemHeadLabels.append(itemHeadLabel)
                self.addSubview(itemView)
                
            }
            self.contentSize = CGSize(width: 0, height: formHeight )
            self.selectDefalutRadioButton()
            SVProgressHUD.dismiss()
        }
        
    }
    
    func parserFailure(urlString: String, error: String) {
        SVProgressHUD.showError(withStatus: error)
    }
}
