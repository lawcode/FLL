//
//  FLLLoginModel.swift
//  FLLProject
//
//  Created by molangwu on 2017/3/28.
//  Copyright © 2017年 law.com. All rights reserved.
//

import Foundation

class FLLLoginRequestModel: NSObject {
    
    var userName = ""
    var UserPassword = ""
    var rould = 1
    var groupName = ""
    var posNum = 0

    override init() {
        super.init()
    }
    
    init(userName: String, userPassword: String, rould: Int, groupName: String, posNum: Int) {
        
        self.userName = userName
        self.UserPassword = userPassword
        self.rould = rould
        self.groupName = groupName
        self.posNum = posNum
    }
    
    init(dict: [String: AnyObject]) {
        super.init()
        setValuesForKeys(dict)
    }
    
}
