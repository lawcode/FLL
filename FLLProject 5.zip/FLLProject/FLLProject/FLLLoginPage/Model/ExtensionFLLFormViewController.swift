//
//  ExtensionFLLFormViewController.swift
//  FLLProject
//
//  Created by molangwu on 2017/3/29.
//  Copyright © 2017年 law.com. All rights reserved.
//

import SVProgressHUD

extension FLLFormViewController: NetWorkingParserDelegate {
    
    func parserFailure(urlString: String, error: String) {
        SVProgressHUD.showError(withStatus: error)
    }
    
    func parserSuccess(urlString: String, result: NetWorkingObjectResult) {
        if urlString == URLEnum.checkLogin.rawValue {
            if let resultData = result.data {
                let loginResponseModel = FLLLoginResponseModel.mj_object(withKeyValues: resultData)
                
                if let itemList: [FLLLoginItemListModel] = FLLLoginItemListModel.mj_objectArray(withKeyValuesArray: loginResponseModel?.list).copy() as? [FLLLoginItemListModel] {
                    SVProgressHUD.showSuccess(withStatus: "更新轮数成功！")
                    SVProgressHUD.dismiss(withDelay: 0.5)
                    self.roundLabel.text = headLabelText[3] + "\(self.currentSelectRound)"
                    self.loginResponseModel = loginResponseModel!
                    self.itemListModel = itemList
                    self.selectAreaRow = 0
                    self.signaturePopoverViewController.headJudgeName = loginResponseModel!.mainJudgerName
                    self.signaturePopoverViewController.judgeName = loginResponseModel!.judgerName
                    initData()
                    if itemList.count == 0 {
                        areaLabel.text = headLabelText[2]
                    } else {
                        areaLabel.text = headLabelText[2] + areaText[0]
                    }
                }
                
            } else {
                SVProgressHUD.show(withStatus: "服务器出问题！")
                SVProgressHUD.dismiss(withDelay: 0.5)
            }

        } else if urlString == URLEnum.submitFormData.rawValue {
            SVProgressHUD.showSuccess(withStatus: "提交成功！")
            SVProgressHUD.dismiss(withDelay: 0.5)
        }
    }
}
