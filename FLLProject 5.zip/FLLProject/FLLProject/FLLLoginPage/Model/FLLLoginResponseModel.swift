//
//  FLLLoginResponseModel.swift
//  FLLProject
//
//  Created by molangwu on 2017/3/28.
//  Copyright © 2017年 law.com. All rights reserved.
//

import Foundation

class FLLLoginResponseModel: NSObject {
    
    var mainJudgerId = 0
    var mainJudgerName = ""
    var judgerId = 0
    var judgerName = ""
    var list: AnyObject?
    
    override init() {
        super.init()
    }
    
    init(dict: [String : AnyObject]) {
        super.init()
        setValuesForKeys(dict)
    }
}

class FLLLoginItemListModel: NSObject {
    
    var partId = 0
    var projectId = 0
    var teamName = ""
    var groupName = ""
    var schoolName = ""
    var menber1 = ""
    var menber2 = ""
    var menber3 = ""
    
    override init() {
        super.init()
    }
    
    init(dict: [String : AnyObject]) {
        super.init()
        setValuesForKeys(dict)
    }
}
